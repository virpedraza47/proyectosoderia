const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();

// Configurar CORS para permitir solicitudes desde cualquier origen
app.use(cors({
    origin: 'http://127.0.0.1:5500', // Especifica el origen permitido
    methods: ['GET', 'POST', 'PUT', 'DELETE'], // Métodos HTTP permitidos
    allowedHeaders: ['Content-Type'], // Headers permitidos
}));

app.use(express.json()); // Para poder parsear JSON en el body

// Crear conexión a la base de datos
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Cambia a tu usuario de MySQL
    password: '1234', // Cambia a tu contraseña de MySQL
    database: 'paginasoderia' // Cambia al nombre de tu base de datos
});

// Conectar a la base de datos
connection.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conexión exitosa a la base de datos');
});

// Ruta para obtener todos los clientes
app.get('/api/clientes', (req, res) => {
    const query = 'SELECT * FROM clientes';
    connection.query(query, (err, results) => {
        if (err) {
            console.error('Error obteniendo los clientes:', err);
            res.status(500).send('Error obteniendo los clientes');
            return;
        }
        res.json(results);
    });
});

// Ruta para obtener un cliente específico por ID
app.get('/api/clientes/:id', (req, res) => {
    const id = req.params.id;
    const query = 'SELECT * FROM clientes WHERE id = ?'; // Cambiado a 'id'
    connection.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error obteniendo el cliente:', err);
            return res.status(500).send('Error obteniendo el cliente');
        }
        
        if (results.length === 0) {
            return res.status(404).send('Cliente no encontrado');
        }

        res.json(results[0]); // Enviar el primer (y único) resultado
    });
});

// Ruta para agregar un nuevo cliente
app.post('/api/clientes', (req, res) => {
    const { nombre, apellido, direccion, telefono, email } = req.body;
    const query = 'INSERT INTO clientes (nombre, apellido, direccion, telefono, email) VALUES (?, ?, ?, ?, ?)';
    connection.query(query, [nombre, apellido, direccion, telefono, email], (err, result) => {
        if (err) {
            console.error('Error agregando cliente:', err);
            res.status(500).send('Error agregando cliente');
            return;
        }
        res.json({ message: 'Cliente agregado con éxito', id: result.insertId });
    });
});

// Ruta para eliminar un cliente
app.delete('/api/clientes/:id', (req, res) => {
  const id = req.params.id;
  try { // Primero, verifica si el cliente existe
      const deleteQuery = 'DELETE FROM clientes WHERE id = ?'; // Cambiado a 'id'
      connection.query(deleteQuery, [id], (err, results) => {
          if (err) {
              console.error(`Error eliminando cliente: ${err}`);
              return res.status(500).send(`Error eliminando cliente ${err}`);
          }
          res.status(201).json({ message: 'Cliente eliminado con exito' });
    });

  } catch (error) {
    return res.status(500).send(`error interno ${error}`)
  }
});
// Ruta para actualizar un cliente
app.put('/api/clientes/:id', (req, res) => {
    const id = req.params.id;
    const { nombre, apellido, direccion, telefono, email } = req.body;
    const query = 'UPDATE clientes SET nombre = ?, apellido = ?, direccion = ?, telefono = ?, email = ? WHERE id = ?'; // Cambiado a 'id'
    connection.query(query, [nombre, apellido, direccion, telefono, email, id], (err, result) => {
        if (err) {
            console.error('Error actualizando cliente:', err);
            res.status(500).send('Error actualizando cliente');
            return;
        }
        res.json({ message: 'Cliente actualizado con éxito' });
    });
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
