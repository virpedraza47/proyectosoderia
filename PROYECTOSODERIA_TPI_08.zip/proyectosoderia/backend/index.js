const express = require('express');
const mysql = require('mysql2');
const cors = require('cors'); // Importar el paquete cors

const app = express();

// Habilitar CORS para permitir solicitudes desde cualquier origen
app.use(cors({
    origin: 'http://127.0.0.1:5500', // Especifica el origen permitido
    methods: ['GET', 'POST', 'PUT', 'DELETE'], // Métodos permitidos
    allowedHeaders: ['Content-Type'], // Headers permitidos
}));

// // Middleware para manejar datos en JSON y formularios
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));

// // Crear conexión a la base de datos
// //const connection = mysql.createConnection({
//   host: 'localhost',
//   user: 'root', // Cambia a tu usuario de MySQL
//   password: '1234', // Cambia a tu contraseña de MySQL
//   database: 'paginasoderia' // Cambia al nombre de tu base de datos
// });

// // Conectar a la base de datos
// connection.connect((err) => {
//   if (err) {
//     console.error('Error conectando a la base de datos:', err);
//     return;
//   }
//   console.log('Conexión exitosa a la base de datos');
// });

// Iniciar el servidor en el puerto 3000
app.listen(3000, () => {
  console.log('Servidor iniciado en el puerto 3000');
});
