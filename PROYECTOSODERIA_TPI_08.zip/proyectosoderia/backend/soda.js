const express = require('express');
const cors = require('cors');
const app = express();
const clientesRoutes = require('./clientes');


// Middleware para manejar datos en JSON y formularios
app.use(express.json());
app.use(express.urlencoded({ extended: true }));



app.use(cors());  // Habilitar CORS para permitir solicitudes desde el frontend
app.use(express.json());  // Habilitar el parsing de JSON

// Ruta para manejar clientes
app.use('/api/clientes', clientesRoutes);

app.listen(3000, () => {
    console.log('Servidor escuchando en el puerto 3000');
});

