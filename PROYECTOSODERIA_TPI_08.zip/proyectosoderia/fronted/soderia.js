document.addEventListener('DOMContentLoaded', () => {
    cargarClientes();
    document.getElementById('clienteForm').addEventListener('submit', agregarCliente);
    document.getElementById('modificarClienteForm').addEventListener('submit', modificarCliente);
});

// Cargar los clientes de la base de datos
function cargarClientes() {
    fetch('http://localhost:3000/api/clientes')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar los clientes');
            }
            return response.json();
        })
        .then(data => {
            const tablaBody = document.getElementById('clientes-table-body');
            tablaBody.innerHTML = ''; // Limpiar la tabla
            data.forEach(cliente => {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td>${cliente.id}</td>
                    <td>${cliente.nombre}</td>
                    <td>${cliente.apellido}</td>
                    <td>${cliente.direccion}</td>
                    <td>${cliente.telefono}</td>
                    <td>${cliente.email}</td>
                    <td>
                        <button class="btn btn-info" onclick="consultarCliente(${cliente.id})">Consultar</button>
                        <button class="btn btn-warning" onclick="abrirModalModificar(${cliente.id})" data-bs-toggle="modal" data-bs-target="#modificarClienteModal">Modificar</button>
                        <button class="btn btn-danger" onclick="eliminarCliente(${cliente.id})">Eliminar</button>
                    </td>
                `;
                tablaBody.appendChild(fila);
            });
        })
        .catch(error => {
            console.error('Error al cargar los clientes:', error);
            alert('Error al cargar los clientes');
        });
}

// Agregar un nuevo cliente
function agregarCliente(event) {
    event.preventDefault(); // Prevenir el envío del formulario
    const nuevoCliente = {
        nombre: document.getElementById('nombre').value,
        apellido: document.getElementById('apellido').value,
        direccion: document.getElementById('direccion').value,
        telefono: document.getElementById('telefono').value,
        email: document.getElementById('email').value,
    };

    fetch('http://localhost:3000/api/clientes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(nuevoCliente),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al agregar el cliente');
        }
        return response.json();
    })
    .then(data => {
        alert(data.message);
        document.getElementById('clienteForm').reset(); // Limpiar el formulario
        cargarClientes(); // Recargar la lista de clientes
    })
    .catch(error => {
        console.error('Error al agregar el cliente:', error);
        alert('Error al agregar el cliente');
    });
}

// Eliminar un cliente
function eliminarCliente(id) {
    fetch(`http://localhost:3000/api/clientes/${id}`, {
        method: 'DELETE',
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al eliminar el cliente');
        }
        return response.json();
    })
    .then(data => {
        alert(data.message);
        cargarClientes(); // Recargar la lista de clientes
    })
    .catch(error => {
        console.error('Error al eliminar el cliente:', error);
        alert('Error al eliminar el cliente');
    });
}

// Consultar un cliente
function consultarCliente(id) {
    fetch(`http://localhost:3000/api/clientes/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al consultar el cliente');
            }
            return response.json();
        })
        .then(data => {
            // Muestra la información del cliente en una alerta
            alert(`ID: ${data.id}\nNombre: ${data.nombre}\nApellido: ${data.apellido}\nDirección: ${data.direccion}\nTeléfono: ${data.telefono}\nEmail: ${data.email}`);
        })
        .catch(error => {
            console.error('Error al consultar el cliente:', error);
            alert('Error al consultar el cliente');
        });
}

// Abrir el modal de modificación y cargar los datos del cliente
function abrirModalModificar(id) {
    fetch(`http://localhost:3000/api/clientes/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al consultar el cliente');
            }
            return response.json();
        })
        .then(data => {
            // Rellenar el formulario con los datos del cliente
            document.getElementById('modificarClienteId').value = data.id;
            document.getElementById('modificarNombre').value = data.nombre;
            document.getElementById('modificarApellido').value = data.apellido;
            document.getElementById('modificarDireccion').value = data.direccion;
            document.getElementById('modificarTelefono').value = data.telefono;
            document.getElementById('modificarEmail').value = data.email;
        })
        .catch(error => {
            console.error('Error al cargar los datos del cliente:', error);
            alert('Error al cargar los datos del cliente');
        });
}

// Modificar un cliente existente
function modificarCliente(event) {
    event.preventDefault(); // Prevenir el envío del formulario
    const id = document.getElementById('modificarClienteId').value;
    const clienteModificado = {
        nombre: document.getElementById('modificarNombre').value,
        apellido: document.getElementById('modificarApellido').value,
        direccion: document.getElementById('modificarDireccion').value,
        telefono: document.getElementById('modificarTelefono').value,
        email: document.getElementById('modificarEmail').value,
    };

    fetch(`http://localhost:3000/api/clientes/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(clienteModificado),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al modificar el cliente');
        }
        return response.json();
    })
    .then(data => {
        alert(data.message);
        cargarClientes(); // Recargar la lista de clientes
        const modal = bootstrap.Modal.getInstance(document.getElementById('modificarClienteModal'));
        modal.hide(); // Cerrar el modal
    })
    .catch(error => {
        console.error('Error al modificar el cliente:', error);
        alert('Error al modificar el cliente');
    });
}
